// Forms Input Mask

$( document ).ready(function() {

    $(".input-mask-trigger").inputmask();
});