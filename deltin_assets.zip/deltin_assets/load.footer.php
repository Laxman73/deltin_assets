<div class="app-wrapper-footer">
  <div class="app-footer">
    <div class="app-footer__inner">
      <div class="text-center text-dark opacity-8 mt-3">&copy; <?php echo date('Y') ?> <?php echo SITE_NAME ?></div>
    </div>
  </div>
</div>

<div class="body-block-example-1 d-none">
    <div class="loader bg-transparent no-shadow p-0">
        <div class="ball-grid-pulse">
            <div class="bg-white"></div>
            <div class="bg-white"></div>
            <div class="bg-white"></div>
            <div class="bg-white"></div>
            <div class="bg-white"></div>
            <div class="bg-white"></div>
            <div class="bg-white"></div>
            <div class="bg-white"></div>
            <div class="bg-white"></div>
        </div>
    </div>
</div>