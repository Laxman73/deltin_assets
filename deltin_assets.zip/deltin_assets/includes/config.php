<?php
// $keyId = 'rzp_test_173Rfe4mnnanVl';
// $keySecret = 'QToG8po57vVRFsoYmAeIl1bn'; //*/

/*$keyId = 'rzp_live_tQNtNfmMoFwADY';
$keySecret = 'cSyXf6YYsqLED2pCxRyPsQwx'; //*/

$keyId = 'rzp_live_MmcsqJar11RjVN';
$keySecret = 'GOCOubDGKqw9M1epJbX26xEa'; //

//$displayCurrency = 'INR';
//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
