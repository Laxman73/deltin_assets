<?php
 // LOCAL
define('SITE_ADDRESS','http://126.0.0.100/deltin_assets/');
define('SITE_ADDRESS2','http://126.0.0.100/deltin_assets/');
define('PWA_SITE_ADDRESS','http://126.0.0.100/deltin_assets/');
define('DOCROOT','/sites/deltin_assets/');
define('SITE_NAME','Deltin Asset Management System');  // 

define('DB_HOST','126.0.0.100');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','assetmgmnt');  // */

/* // STAGING
define('SITE_ADDRESS','http://staging.teaminertia.com/mrfarmer_staff/');
define('SITE_ADDRESS2','http://staging.teaminertia.com/mrfarmer_staff/');
define('PWA_SITE_ADDRESS','http://staging.teaminertia.com/mrfarmer_staff/');
define('DOCROOT','/stagin27/public_html/mrfarmer_staff/');
define('SITE_NAME','');  // 

define('DB_HOST','localhost');
define('DB_USERNAME','stagin27_mfr_staff');
define('DB_PASSWORD','of3oQ&y0Yabc');
define('DB_NAME','stagin27_mfr_staff');  // */

/* // LIVE
// */
?>